package com.example.naturalaicamera

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private lateinit var cameraPreview: PreviewView
    private lateinit var photoPreview: ImageView
    private lateinit var statusText: TextView
    private lateinit var captureButton: MaterialButton
    private lateinit var enhanceButton: MaterialButton
    private lateinit var saveButton: MaterialButton
    private lateinit var cameraExecutor: ExecutorService

    private var imageCapture: ImageCapture? = null
    private var originalBitmap: Bitmap? = null
    private var enhancedBitmap: Bitmap? = null
    private var isShowingPhoto = false

    private val requestCameraPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera() else setStatus("Camera permission denied. You can still choose a photo from Gallery.")
        }

    private val pickPhoto =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let { loadPhoto(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        cameraPreview = findViewById(R.id.cameraPreview)
        photoPreview = findViewById(R.id.photoPreview)
        statusText = findViewById(R.id.statusText)
        captureButton = findViewById(R.id.captureButton)
        enhanceButton = findViewById(R.id.enhanceButton)
        saveButton = findViewById(R.id.saveButton)
        cameraExecutor = Executors.newSingleThreadExecutor()

        findViewById<MaterialButton>(R.id.galleryButton).setOnClickListener {
            pickPhoto.launch("image/*")
        }
        captureButton.setOnClickListener { capturePhoto() }
        enhanceButton.setOnClickListener { enhancePhoto() }
        saveButton.setOnClickListener { savePhoto() }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            requestCameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(cameraPreview.surfaceProvider)
            }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()
            try {
                provider.unbindAll()
                provider.bindToLifecycle(
                    this,
                    CameraSelector.DEFAULT_BACK_CAMERA,
                    preview,
                    imageCapture
                )
                showCamera()
                setStatus("Camera ready")
            } catch (e: Exception) {
                setStatus("Could not start camera: ${e.localizedMessage ?: "unknown error"}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun capturePhoto() {
        val capture = imageCapture
        if (capture == null) {
            Toast.makeText(this, "Camera is not ready yet", Toast.LENGTH_SHORT).show()
            return
        }
        capture.takePicture(cameraExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: androidx.camera.core.ImageProxy) {
                try {
                    val buffer = image.planes[0].buffer
                    val bytes = ByteArray(buffer.remaining())
                    buffer.get(bytes)
                    val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    runOnUiThread {
                        if (bitmap != null) {
                            originalBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true)
                            enhancedBitmap = null
                            photoPreview.setImageBitmap(originalBitmap)
                            showPhoto()
                            saveButton.isEnabled = true
                            setStatus("Photo captured. Tap Enhance for a natural clean-up.")
                        } else {
                            setStatus("Could not read the captured photo. Try Gallery or capture again.")
                        }
                    }
                } catch (e: Exception) {
                    runOnUiThread { setStatus("Capture failed: ${e.localizedMessage ?: "unknown error"}") }
                } finally {
                    image.close()
                }
            }

            override fun onError(exception: ImageCaptureException) {
                runOnUiThread { setStatus("Capture failed: ${exception.localizedMessage ?: "unknown error"}") }
            }
        })
    }

    private fun loadPhoto(uri: Uri) {
        try {
            val stream: InputStream? = contentResolver.openInputStream(uri)
            val bitmap = stream.use { BitmapFactory.decodeStream(it) }
            if (bitmap == null) {
                setStatus("Could not open this image.")
                return
            }
            originalBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true)
            enhancedBitmap = null
            photoPreview.setImageBitmap(originalBitmap)
            showPhoto()
            saveButton.isEnabled = true
            setStatus("Photo loaded. Tap Enhance for a natural clean-up.")
        } catch (e: Exception) {
            setStatus("Could not load photo: ${e.localizedMessage ?: "unknown error"}")
        }
    }

    // A lightweight, on-device natural enhancement prototype (not a trained AI model).
    // Keeps changes gentle: slight contrast and saturation adjustment with a restrained sharpen pass.
    private fun enhancePhoto() {
        val source = originalBitmap
        if (source == null) {
            Toast.makeText(this, "Capture a photo or choose one from Gallery first", Toast.LENGTH_SHORT).show()
            return
        }
        setStatus("Enhancing photo…")
        cameraExecutor.execute {
            try {
                val result = naturalEnhance(source)
                runOnUiThread {
                    enhancedBitmap = result
                    photoPreview.setImageBitmap(result)
                    showPhoto()
                    saveButton.isEnabled = true
                    setStatus("Natural enhancement complete. Save it or try another photo.")
                }
            } catch (e: Exception) {
                runOnUiThread { setStatus("Enhancement failed: ${e.localizedMessage ?: "unknown error"}") }
            }
        }
    }

    private fun naturalEnhance(input: Bitmap): Bitmap {
        val w = input.width
        val h = input.height
        val src = IntArray(w * h)
        input.getPixels(src, 0, w, 0, 0, w, h)
        val adjusted = IntArray(src.size)

        // Mild contrast and saturation; preserve natural skin tones as much as possible.
        for (i in src.indices) {
            val c = src[i]
            val r0 = Color.red(c).toFloat()
            val g0 = Color.green(c).toFloat()
            val b0 = Color.blue(c).toFloat()
            val r = ((r0 - 128f) * 1.06f + 128f).coerceIn(0f, 255f)
            val g = ((g0 - 128f) * 1.06f + 128f).coerceIn(0f, 255f)
            val b = ((b0 - 128f) * 1.06f + 128f).coerceIn(0f, 255f)
            val luma = 0.299f * r + 0.587f * g + 0.114f * b
            val saturation = 1.035f
            val nr = (luma + (r - luma) * saturation).coerceIn(0f, 255f).toInt()
            val ng = (luma + (g - luma) * saturation).coerceIn(0f, 255f).toInt()
            val nb = (luma + (b - luma) * saturation).coerceIn(0f, 255f).toInt()
            adjusted[i] = Color.argb(Color.alpha(c), nr, ng, nb)
        }

        // Gentle unsharp mask approximation. Avoid processing borders.
        val output = adjusted.copyOf()
        if (w >= 3 && h >= 3) {
            for (y in 1 until h - 1) {
                for (x in 1 until w - 1) {
                    val i = y * w + x
                    val center = adjusted[i]
                    val neighbours = intArrayOf(
                        adjusted[i - 1], adjusted[i + 1],
                        adjusted[i - w], adjusted[i + w]
                    )
                    fun sharpen(channel: (Int) -> Int): Int {
                        val c = channel(center).toFloat()
                        val avg = neighbours.map { channel(it).toFloat() }.average().toFloat()
                        return (c + 0.18f * (c - avg)).coerceIn(0f, 255f).toInt()
                    }
                    output[i] = Color.argb(
                        Color.alpha(center),
                        sharpen(Color::red),
                        sharpen(Color::green),
                        sharpen(Color::blue)
                    )
                }
            }
        }
        return Bitmap.createBitmap(output, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun savePhoto() {
        val bitmap = enhancedBitmap ?: originalBitmap
        if (bitmap == null) {
            setStatus("There is no photo to save.")
            return
        }
        try {
            val name = "NaturalAI_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/NaturalAICamera")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri == null) {
                setStatus("Could not create a file for saving.")
                return
            }
            contentResolver.openOutputStream(uri)?.use { output ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, output)
            }
            setStatus("Saved to Pictures/NaturalAICamera")
            Toast.makeText(this, "Photo saved", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            setStatus("Save failed: ${e.localizedMessage ?: "unknown error"}")
        }
    }

    private fun showPhoto() {
        isShowingPhoto = true
        photoPreview.visibility = View.VISIBLE
        cameraPreview.visibility = View.GONE
    }

    private fun showCamera() {
        isShowingPhoto = false
        photoPreview.visibility = View.GONE
        cameraPreview.visibility = View.VISIBLE
    }

    private fun setStatus(message: String) {
        statusText.text = message
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}
