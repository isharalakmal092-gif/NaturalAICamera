# APK එක build කරගන්න සරලම ක්‍රමය

මෙම project එකේ `.github/workflows/build-apk.yml` GitHub Actions workflow එක ඇතුළත් කර ඇත. එය GitHub මත Android debug APK එක build කර Artifact එකක් ලෙස ලබා දෙයි.

1. GitHub.com එකට sign in වෙන්න.
2. New repository එකක් හදන්න (උදා: `NaturalAICamera`).
3. ZIP එක extract කර එහි ඇතුළත තියෙන files/folders සියල්ල repository එකට upload කර commit කරන්න. `.github` hidden folder එකත් upload කරන්න.
4. Repository එකේ **Actions** tab එකට යන්න.
5. **Build Android APK** workflow එක තෝරා **Run workflow** ඔබන්න (push කළ විටත් auto-run වේ).
6. Run එක සාර්ථක වූ පසු workflow run එක විවෘත කර **Artifacts** යටතේ `NaturalAICamera-debug-apk` download කරන්න.
7. ZIP එක extract කර `app-debug.apk` Android phone එකට ගෙන install කරන්න. Android ඉල්ලුවොත් මේ source එකෙන් install කිරීමට browser/file manager permission දෙන්න.

මෙය debug APK එකකි. මේ පරිසරයේ Android SDK/Gradle build environment නොමැති නිසා APK එක මෙතැනම compile කර පරීක්ෂා කර නැත. Build එකේ error එකක් ආවොත් Actions log එකෙන් error එක බලන්න.
