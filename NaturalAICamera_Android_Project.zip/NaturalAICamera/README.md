# Natural AI Camera — Android starter project

This is a native Kotlin Android starter project with:
- Live camera preview and capture using CameraX
- Gallery image picker
- A natural-looking, on-device enhancement prototype
- Save output to `Pictures/NaturalAICamera`

## Important note
The included enhancement is **not a trained AI model**. It is a lightweight image-processing prototype (gentle contrast, saturation, and sharpening) so the app can be tried as a starter without downloading a model. It cannot truly recover details that were never captured, and strong blur cannot always be fixed.

## Build
1. Open this folder in Android Studio (Hedgehog or newer recommended).
2. Allow Gradle sync to download dependencies.
3. Use JDK 17.
4. Run on an Android phone or emulator (a physical phone is best for camera testing).

No `local.properties` or device-specific paths are included. The Gradle wrapper is not included; Android Studio can import the project using its installed Gradle, or generate a wrapper from the Gradle tool window.

## Next step for real AI enhancement
Integrate a compact on-device super-resolution / denoise model (for example a compatible TensorFlow Lite model) and benchmark memory, processing time, skin texture, and image quality on the target phone. Model licensing and device performance should be checked before distribution.
